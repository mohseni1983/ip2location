export class GetIpLocationDto {
  ip:string
}