export class IpLocationDto {
  ip:string
  location:string
  symbol:string
}